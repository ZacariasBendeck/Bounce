# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Sun Sep 13 02:18:26 2015)---
runfile('C:/Users/Usuario/Dropbox/Cursos/Python For Kids/Ch.13 Game Bounce/Bounce3.py', wdir='C:/Users/Usuario/Dropbox/Cursos/Python For Kids/Ch.13 Game Bounce')